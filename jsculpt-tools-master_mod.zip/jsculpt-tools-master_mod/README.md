# JSculpt tools
Blender 3.2 sculpting utilities addon (before: Fast Sculpt)

https://github.com/NimeNayota/jsculpt-tools/assets/118754270/bbe513b6-6abb-426c-b906-7573211f990f

