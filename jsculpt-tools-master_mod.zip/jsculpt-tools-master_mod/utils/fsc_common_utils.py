import bpy

def get_axis_no(str_axis):
    if str_axis == "X":
        return 0
    elif str_axis == "Y":
        return 1
    
    return 2